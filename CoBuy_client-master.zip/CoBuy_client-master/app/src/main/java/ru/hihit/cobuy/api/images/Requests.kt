package ru.hihit.cobuy.api.images

import kotlinx.serialization.Serializable

